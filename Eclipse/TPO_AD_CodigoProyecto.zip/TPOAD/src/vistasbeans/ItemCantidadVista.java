package vistasbeans;

public class ItemCantidadVista {

	private int cantidad;
	private RodamientoVista rodamiento;
}
