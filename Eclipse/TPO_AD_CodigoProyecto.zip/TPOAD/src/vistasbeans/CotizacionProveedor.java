package vistasbeans;

import java.util.Vector;

public class CotizacionProveedor {

	private Vector<ItemCotizacionVista> items;
	private ProveedorVista proveedor;
}
