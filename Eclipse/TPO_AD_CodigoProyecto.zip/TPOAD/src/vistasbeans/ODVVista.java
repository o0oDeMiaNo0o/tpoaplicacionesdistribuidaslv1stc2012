package vistasbeans;

public class ODVVista {

	private String direccion;
	private String responsable;
	private int IdODV;
	
}
