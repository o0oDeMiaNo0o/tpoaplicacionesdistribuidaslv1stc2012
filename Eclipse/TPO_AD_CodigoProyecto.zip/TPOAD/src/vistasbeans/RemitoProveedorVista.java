package vistasbeans;

public class RemitoProveedorVista extends RemitoVista{

	private OrdenCompraVista ordenCompra;
	private ProveedorVista proveedor;
}
