package vistasbeans;

public class ItemPrecioVista {

	private int cantidad;
	private float precioCosto;
	private float precioVenta;
	private RodamientoVista rodamiento;
	
}
