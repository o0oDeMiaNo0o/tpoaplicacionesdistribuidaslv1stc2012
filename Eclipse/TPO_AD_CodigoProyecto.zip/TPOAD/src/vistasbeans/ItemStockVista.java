package vistasbeans;

import java.util.Date;

public class ItemStockVista {

	private int cantidad;
	private String estado;
	private float precioCosto;
	private float precioVenta;
	private RodamientoVista rodamiento;
	private Date ultimaActualizacion;
}
