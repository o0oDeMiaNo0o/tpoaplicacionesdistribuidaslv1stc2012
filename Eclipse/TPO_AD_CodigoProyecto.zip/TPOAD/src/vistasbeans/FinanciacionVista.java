package vistasbeans;

public class FinanciacionVista {

	private int cuotas;
	private float recargo; //creo que un float quedar�a mejor
}
