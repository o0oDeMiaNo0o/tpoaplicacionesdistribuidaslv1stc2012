package vistasbeans;

public class RodamientoVista {

	private int id;
	private String codigo; //creo que por ah� deber�a ser un string
	private String marca;
	private String nroSerie;
	private String origen;
	private String sufijo;
}
