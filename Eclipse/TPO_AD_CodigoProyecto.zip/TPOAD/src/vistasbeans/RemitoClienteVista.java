package vistasbeans;

import java.util.Vector;

public class RemitoClienteVista extends RemitoVista{

	private ClienteVista cliente;
	private Vector<OrdenPedidoVista> ordenPedido;
}
