package vistasbeans;

public class ItemCotizacionVista {

	private int cantidad;
	private float precio;
	private RodamientoVista rodamiento;
}
