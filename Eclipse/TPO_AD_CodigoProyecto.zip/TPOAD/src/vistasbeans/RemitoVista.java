package vistasbeans;

import java.util.Date;
import java.util.Vector;

public class RemitoVista {

	private Date fecha;
	private Vector<ItemCantidadVista> items;
	private int nro;
	private String estadoEnvio;
}
