package vistasbeans;

import java.util.Vector;

public class RemitoTransporteVista extends RemitoVista{

	private ODVVista odv;
	private Vector<OrdenPedidoVista> ordenPedido;
}
