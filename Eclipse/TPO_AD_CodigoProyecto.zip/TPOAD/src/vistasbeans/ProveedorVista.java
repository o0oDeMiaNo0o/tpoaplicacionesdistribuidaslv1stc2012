package vistasbeans;

import java.util.Vector;

public class ProveedorVista {

	private String direccion;
	private Vector<ListaPrecioVista> listaPrecios;
	private int nro;
	private String razonSocial;
	private String telefono;
}
