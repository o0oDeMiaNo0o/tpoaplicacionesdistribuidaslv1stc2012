package vistasbeans;

import java.util.Date;
import java.util.Vector;

public class ListaPrecioVista {

	private int descuentoContado;
	private Date fechaEmision;
	private Date fechaVencimiento;
	private Vector<FinanciacionVista> financiacion;
	private Vector<ItemPrecioVista> items;
	private int nro;
	private int nroListReemplazo;
	
}
